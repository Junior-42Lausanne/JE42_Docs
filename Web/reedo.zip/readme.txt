Desktop + WebFont license

Introducing Reedo, a modern cut-off typeface with a modern twist. Unique and playful family style will help you decorate your design. This font is perfect for your branding projects, logo designs, magazine headers, T-shirt ads, website headers, and more.

This modern typeface is perfect if you're in the clothing branding business. Its unique style will allow you to bring your brand to a new level. An expensive brutal typeface will draw the attention of many customers to your brand.

Also this font will suit you if you are fond of sports design. This font will complement your sports team design well and can beautify your team cover. Its brutality and good readability can allow it to be printed on your jerseys.

The unique design of the numbers gives a unique interest to the numbers. The numbers show a unique wave-like pattern.

The font contains 2 weights Regular and Bold, upper and lower case letters and a basic set of glyphs.

Pay what you like:
https://teewwa.gumroad.com/l/Reedo

Follow:
https://www.behance.net/tewa