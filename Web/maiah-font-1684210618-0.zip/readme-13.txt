📜 By installing or using this font, you agree to the Product Usage Agreement:

- You can use this font for PERSONAL & COMMERCIAL USE ONLY!

- Here is the link to purchase a commercial license:
https://creativefinest.com/product/maiah-serif-font-family-pack/

- For Corporate use, you have to purchase a Corporate license
https://creativefinest.com/product/maiah-serif-font-family-pack/

- If you need a custom license, don't hesitate to get in touch with us at
sales@creativefinest.com

Please visit our store for more amazing fonts :
https://creativefinest.com

Follow our website for updates: https://creativetacos.com

Thank you.